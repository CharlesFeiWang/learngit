package com.xiangxue.common;

public class CommonDataBindingAdapters {
}
