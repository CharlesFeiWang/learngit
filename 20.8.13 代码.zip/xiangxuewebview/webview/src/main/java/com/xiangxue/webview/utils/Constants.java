package com.xiangxue.webview.utils;

public class Constants {
    public static final String TITLE = "title";
    public static final String URL = "url";
    public static final String IS_SHOW_ACTION_BAR = "is_show_action_bar";
    public static final String CAN_NATIVE_REFRESH = "can_native_refresh";
    public static final String ANDROID_ASSET_URI = "file:///android_asset/";
}
