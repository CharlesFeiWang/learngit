package com.xiangxue.webview.webviewprocess;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.xiangxue.webview.bean.JsParam;
import com.xiangxue.webview.webviewprocess.settings.WebViewDefaultSettings;
import com.xiangxue.webview.WebViewCallBack;

import com.xiangxue.webview.webviewprocess.webchromeclient.XiangxueWebChromeClient;
import com.xiangxue.webview.webviewprocess.webviewclient.XiangxueWebViewClient;

import org.w3c.dom.Text;

import java.util.Map;

public class BaseWebView extends WebView {
    public static final String TAG = "XiangxueWebView";
    public BaseWebView(Context context) {
        super(context);
        init();
    }

    public BaseWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BaseWebView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    public BaseWebView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    public void init(){
        WebViewDefaultSettings.getInstance().setSettings(this);
        addJavascriptInterface(this, "xiangxuewebview");
    }

    public void registerWebViewCallBack(WebViewCallBack webViewCallBack){
        setWebViewClient(new XiangxueWebViewClient(webViewCallBack));
        setWebChromeClient(new XiangxueWebChromeClient(webViewCallBack));
    }

    @JavascriptInterface
    public void takeNativeAction(final String jsParam){
        Log.i(TAG, jsParam);
        if(!TextUtils.isEmpty(jsParam)) {
            final JsParam jsParamObject = new Gson().fromJson(jsParam, JsParam.class);
            if(jsParamObject != null) {
                if("showToast".equalsIgnoreCase(jsParamObject.name)) {
                    Toast.makeText(getContext(), String.valueOf(new Gson().fromJson(jsParamObject.param, Map.class).get("message")), Toast.LENGTH_LONG).show();
                }
            }
        }
    }
}
