package com.xiangxue.webview.bean;

import com.google.gson.JsonObject;

public class JsParam {
    public String name;
    public JsonObject param;
}
